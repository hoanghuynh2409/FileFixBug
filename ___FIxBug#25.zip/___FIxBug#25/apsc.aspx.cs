/****************************************************************************
 * 
 *  Permission to use, copy, modify, distribute and sell this software (or 
 *  code file) and its documentation for any purpose is STRICTLY PROHIBITED. 
 *  This file is provided "as is" without expressed or implied warranty.
 *  
 * **************************************************************************
 *
 *  Copyright(c) 2009-2011 Compunix, LLC. 
 *  Please visit http://www.compunix.us for licensing information.
 *   
 *  THE ABOVE NOTICE MUST REMAIN INTACT.
 * 
 * **************************************************************************/

using System;
using System.Collections.Generic;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Data.SqlClient;
using System.Web;
using System.Web.Routing;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using AspDotNetStorefrontCore;

namespace AspDotNetStorefront
{
    //COMPUNIX
    public partial class apsc : SkinBase
    {
        #region Constants

        public const string MakeQueryStringParam = "make";
        public const string ModelQueryStringParam = "model";
        public const string YearQueryStringParam = "year";
        public const string SubModelQueryStringParam = "submodel";

        #endregion Constants

        #region Event Handlers

        protected void Page_Load(object sender, EventArgs e)
        {
            if (AppLogic.AppConfigBool("GoNonSecureAgain"))
            {
                SkinBase.GoNonSecureAgain();
            }

            CompunixCommon.mmyHelper mh = new CompunixCommon.mmyHelper();
            this.ltOutput.Text = mh.APSCPartsHandler(ThisCustomer);

            SectionTitle = "";
        }

        protected override void OnPreInit(EventArgs e)
        {
            if (!Request.RawUrl.Contains("-parts"))
            {
                CreateDefaultCustomerWhenNecessary();
            }

            base.OnPreInit(e);
        }

        #endregion Event Handlers

        #region Private Methods

        public void CreateDefaultCustomerWhenNecessary()
        {
            if (HttpContext.Current == null)
            {
                return;
            }

            var currentUserPrincipal = HttpContext.Current.User as AspDotNetStorefrontPrincipal;
            if (currentUserPrincipal == null ||
                currentUserPrincipal.ThisCustomer == null)
            {
                return;
            }

            // Create new customer with default information. But only insert the new customer to database in the current user doesn't exist in database.
            currentUserPrincipal.ThisCustomer.RequireCustomerRecord();

            string make;
            string model;
            string year;
            string subModel;
            GetMakeModelYearSubModelFromUrl(out make, out model, out year, out subModel);

            InsertDefaultCustomerInfoForMakeModelYear(currentUserPrincipal.ThisCustomer.CustomerID, make, model, year, subModel);
        }

        private void GetMakeModelYearSubModelFromUrl(out string make, out string model, out string year, out string subModel)
        {
            make = CommonLogic.QueryStringCanBeDangerousContent(MakeQueryStringParam);
            model = CommonLogic.QueryStringCanBeDangerousContent(ModelQueryStringParam);
            year = CommonLogic.QueryStringCanBeDangerousContent(YearQueryStringParam);
            subModel = CommonLogic.QueryStringCanBeDangerousContent(SubModelQueryStringParam);
        }

        private void InsertDefaultCustomerInfoForMakeModelYear(int customerId, string make, string model, string year, string subModel)
        {
            // Validate input data.
            if (customerId < 1)
            {
                return;
            }

            var listOfParas = new List<SqlParameter>();

            var para = new SqlParameter("@CustomerID", SqlDbType.Int) { Value = customerId };
            listOfParas.Add(para);

            para = new SqlParameter("@Make", SqlDbType.NVarChar, 200) { Value = make };
            listOfParas.Add(para);

            para = new SqlParameter("@Model", SqlDbType.NVarChar, 200) { Value = model };
            listOfParas.Add(para);

            para = new SqlParameter("@Year", SqlDbType.NVarChar, 200) { Value = year };
            listOfParas.Add(para);

            para = new SqlParameter("@SubModel", SqlDbType.NVarChar, 1000) { Value = subModel };
            listOfParas.Add(para);

            DB.ExecuteStoredProcInt("mysp_InsertDefaultCustomerInfoForMakeModelYearControl", listOfParas.ToArray());
        }

        #endregion Private Methods
    }
}
